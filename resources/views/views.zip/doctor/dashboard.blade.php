@extends('layouts.admin') 
@section('content')
    <h1 class="h3 mb-4 text-gray-800">Doctor Dashboard</h1>
    <div class="card shadow mb-4">
        <div class="card-body">
            Welcome, Doc! Your schedule will appear here.
        </div>
    </div>
@endsection